export default [
 {   avatarIcon: '../images/Java.png',
   userName: 'Java', handle: 'Java', },
 {   avatarIcon: '../images/Relativity.png',
   userName: 'Relativity Space',
   handle: 'relativityspace', },
 {   avatarIcon: '../images/Virgin.png',
   userName: 'Virgin Galactic',
   handle: 'virgingalactic', },
 {   avatarIcon: '../images/NASA.png',
   userName: 'NASA', handle: 'NASA', },
 {   avatarIcon: '../images/Tesla.png',
   userName: 'Tesla', handle: 'Tesla', }, ];

