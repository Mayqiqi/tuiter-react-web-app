export default [

    {link: "../HomeScreen/index.html", icon: "fa fa-home",style:"wd-font-size d-none d-xl-inline", title:"Home"},
    {link: "../explore/index.html", icon: "fa fa-hashtag",style:"wd-font-size d-none d-xl-inline", title: "Explore"},
    {link: "#", icon: "fa fa-bell", style:"wd-font-size d-none d-xl-inline", title: "Notifications"},
    {link: "#", icon: "fa fa-envelope",style:"wd-font-size d-none d-xl-inline",  title: "Messages"},
    {link: "#", icon: "fa fa-bookmark", style:"wd-font-size d-none d-xl-inline", title: "Bookmarks"},
    {link: "#", icon: "fa fa-list", style:"wd-font-size d-none d-xl-inline", title: "Lists"},
    {link: "#", icon: "fa fa-user", style:"wd-font-size d-none d-xl-inline", title: "Profile"},
    {link: "#", icon: "fa fa-caret-down", style:"wd-font-size d-none d-xl-inline", title: "More"},
];